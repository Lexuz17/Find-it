//
//  ContentView.swift
//  RewardQuiz
//
//  Created by felicia on 13/05/23.
//

import SwiftUI
import CoreData

struct ContentView: View {
    var body: some View {
        ZStack{
            VStack(spacing: 20) {
                Image("RewardImage") //
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                
                Text("Congratulations!")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(Color(red: 0.34, green: 0.366, blue: 0.692, opacity: 1.0))
                
                Text("You have finished the test.")
                    .font(.headline)
                    .foregroundColor(Color(red: 0.3411764705882353, green: 0.36470588235294116, blue: 0.6901960784313725))
                
                Button(action: {
                    // Handle button tap here
                }, label: {
                    Text("Result")
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.vertical, 12)
                        .padding(.horizontal, 34)
                        .background(Color(red: 0.3411764705882353, green: 0.36470588235294116, blue: 0.6901960784313725))
                        .cornerRadius(20)
                })
            }
            .padding()
        }
        .background(
            LinearGradient(colors: [.white, Color(
                red: 231 / 255,
                green: 232 / 255,
                blue: 255 / 255
            )], startPoint: .top, endPoint: .center)
                .edgesIgnoringSafeArea(.all)
        )
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
