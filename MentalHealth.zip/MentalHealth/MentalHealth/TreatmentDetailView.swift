//
//  TreatmentDetailView.swift
//  MentalHealth
//
//  Created by felicia on 14/05/23.
//

import Foundation
import SwiftUI

struct Task: Identifiable {
    var id = UUID()
    var title: String
    var date: Date
}

struct TreatmentDetailView: View {
    var task: Task
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(task.title)
                .font(.headline)
            Text(task.date, style: .date)
                .font(.subheadline)
                .foregroundColor(.gray)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(8)
        .shadow(radius: 4)
    }
}

struct TreatmentManagerView: View {
    @State private var selectedDate = Date()
    @State private var tasks: [Task] = [
        Task(title: "Finish SwiftUI tutorial", date: Date()),
        Task(title: "Prepare for meeting", date: Date()),
        Task(title: "Clean the house", date: Date()),
        Task(title: "Buy groceries", date: Date()),
        Task(title: "Exercise", date: Date())
    ]
    
    var body: some View {
        VStack(spacing: 20) {
            DatePicker(
                selection: $selectedDate,
                displayedComponents: [.date],
                label: { Text("Selected Date") }
            )
            
            ScrollView {
                LazyVStack(spacing: 20) {
                    ForEach(tasks.filter { Calendar.current.isDate($0.date, inSameDayAs: selectedDate) }) { task in
                        TreatmentDetailView(task: task)
                    }
                }
            }
        }
        .padding()
    }
}

struct TreatmentDetailView_Previews: PreviewProvider {
    static var previews: some View {
        let task = Task(title: "Complete project", date: Date().addingTimeInterval(3600))
        TreatmentDetailView(task: task)
    }
}

