//
//  MentalHealthApp.swift
//  MentalHealth
//
//  Created by felicia on 09/05/23.
//

import SwiftUI

@main
struct MentalHealthApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
