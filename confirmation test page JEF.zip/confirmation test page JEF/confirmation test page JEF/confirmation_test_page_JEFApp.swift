//
//  confirmation_test_page_JEFApp.swift
//  confirmation test page JEF
//
//  Created by felicia on 12/05/23.
//

import SwiftUI

@main
struct confirmation_test_page_JEFApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
